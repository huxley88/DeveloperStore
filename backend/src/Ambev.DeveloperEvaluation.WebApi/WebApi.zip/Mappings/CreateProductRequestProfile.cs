using AutoMapper;
using Ambev.DeveloperEvaluation.Application.Products.Create;

namespace Ambev.DeveloperEvaluation.WebApi.Mappings;

public class CreateProductRequestProfile : Profile
{
    public CreateProductRequestProfile()
    {
        CreateMap<CreateProductRequestProfile, CreateProductCommand>();
    }
}
