using AutoMapper;
using Ambev.DeveloperEvaluation.Application.Users.Create;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Users.Create;

public class CreateUserProfile : Profile
{
    public CreateUserProfile()
    {
        CreateMap<CreateUserRequest, CreateUserCommand>();
        CreateMap<CreateUserResult, CreateUserResponse>();
    }
}
