using AutoMapper;
using Ambev.DeveloperEvaluation.WebApi.Features.Sales.CreateSaleApiRequest;
using Ambev.DeveloperEvaluation.Application.Sales.Create;

namespace Ambev.DeveloperEvaluation.WebApi.Mappings;

public class CreateSaleRequestProfile : Profile
{
    public CreateSaleRequestProfile()
    {
        CreateMap<CreateSaleRequest, CreateSaleCommand>();
    }
}
