using AutoMapper;
using Ambev.DeveloperEvaluation.WebApi.Features.Customers.CreateCustomer;
using Ambev.DeveloperEvaluation.Application.Customers.Create;

namespace Ambev.DeveloperEvaluation.WebApi.Mappings;

public class CreateCustomerRequestProfile : Profile
{
    //public CreateSaleRequestProfile()
    //{
    //    CreateMap<CreateCustomerRequest, CreateCustomerCommand>();
    //}
}
