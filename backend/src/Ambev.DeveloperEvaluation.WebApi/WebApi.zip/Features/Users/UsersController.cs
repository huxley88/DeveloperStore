using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Users;

[ApiController]
[Route("api/[controller]")]
//[Authorize]
public class UsersController : ControllerBase
{
    private readonly UserManager<IdentityUser> _userManager;
    public UsersController(UserManager<IdentityUser> userManager) => _userManager = userManager;

    [HttpGet]
    //[Authorize(Roles="Admin")]
    public IActionResult ListUsers()
    {
        var users = _userManager.Users.Select(u => new { u.Id, u.UserName, u.Email }).ToList();
        return Ok(users);
    }

    public record ChangePasswordRequest(string? UserId, string CurrentPassword, string NewPassword);

    [HttpPost("change-password")]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest req)
    {
        IdentityUser? user = null;

        if (!string.IsNullOrWhiteSpace(req.UserId))
        {
            if (!User.IsInRole("Admin")) return Forbid();
            user = await _userManager.FindByIdAsync(req.UserId!);
            if (user is null) return NotFound();
            var token = await _userManager.GeneratePasswordResetTokenAsync(user);
            var r = await _userManager.ResetPasswordAsync(user, token, req.NewPassword);
            if (!r.Succeeded) return BadRequest(r.Errors);
            return NoContent();
        }
        else
        {
            var me = await _userManager.GetUserAsync(User);
            if (me is null) return Unauthorized();
            var r = await _userManager.ChangePasswordAsync(me, req.CurrentPassword, req.NewPassword);
            if (!r.Succeeded) return BadRequest(r.Errors);
            return NoContent();
        }
    }
}