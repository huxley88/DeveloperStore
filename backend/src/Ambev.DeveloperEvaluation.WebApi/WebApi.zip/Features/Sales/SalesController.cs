using AutoMapper;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Ambev.DeveloperEvaluation.WebApi.Common;
using Ambev.DeveloperEvaluation.Application.Sales.Create;
using Ambev.DeveloperEvaluation.Application.Sales.Get;
using Ambev.DeveloperEvaluation.Application.Sales.List;
using Ambev.DeveloperEvaluation.Application.Sales.Update;
using Ambev.DeveloperEvaluation.Application.Sales.Cancel;
using Ambev.DeveloperEvaluation.Application.Sales.CancelItem;
using Ambev.DeveloperEvaluation.WebApi.Features.Sales.UpdateSaleApi;
using Ambev.DeveloperEvaluation.WebApi.Features.Sales.CreateSaleApi;
using Microsoft.AspNetCore.Authorization;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Sales;

[ApiController]
[Route("api/[controller]")]
//[Authorize]
public class SalesController : BaseController
{
    private readonly IMediator _mediator;
    private readonly IMapper _mapper;

    public SalesController(IMediator mediator, IMapper mapper)
    {
        _mediator = mediator;
        _mapper = mapper;
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateSale request, CancellationToken cancellationToken)
    {
        var validator = new CreateSaleApiValidator();

        var result = await validator.ValidateAsync(request, cancellationToken);
        if (!result.IsValid) return BadRequest(result.Errors);

        var cmd = _mapper.Map<CreateSaleCommand>(request);
        var created = await _mediator.Send(cmd, cancellationToken);
        return Created($"/api/sales/{created.Id}", created);
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken cancellationToken)
    {
        var sale = await _mediator.Send(new GetSaleCommand(id), cancellationToken);
        if (sale == null) return NotFound();
        return Ok(sale);
    }

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 20, CancellationToken cancellationToken = default)
          => Ok(await _mediator.Send(new ListSalesQuery(page, pageSize), cancellationToken));

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(string id, [FromBody] UpdateSale request, CancellationToken cancellationToken)
    {
        var validator = new UpdateSaleValidator();
        var result = await validator.ValidateAsync(request, cancellationToken);
        if (!result.IsValid) return BadRequest(result.Errors);

        var cmd = new UpdateSaleCommand(id, request.CustomerName, request.BranchName, request.Items);
        var ok = await _mediator.Send(cmd, cancellationToken);
        if (!ok) return NotFound();
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Cancel(string id, CancellationToken cancellationToken)
    {
        var ok = await _mediator.Send(new CancelSaleCommand(id), cancellationToken);
        if (!ok) return NotFound();
        return NoContent();
    }

    [HttpPost("{id}/items/{productId}/cancel")]
    public async Task<IActionResult> CancelItem(Guid id, Guid productId, CancellationToken cancellationToken)
    {
        var ok = await _mediator.Send(new CancelItemCommand(id, productId), cancellationToken);
        if (!ok) return NotFound();
        return NoContent();
    }
}