
using FluentValidation;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Sales.UpdateSaleApi;

public class UpdateSaleValidator : AbstractValidator<UpdateSale>
{
    public UpdateSaleValidator()
    {
        RuleFor(x => x.CustomerName).NotEmpty();
        RuleFor(x => x.BranchName).NotEmpty();
        RuleFor(x => x.Items).NotEmpty();
    }
}
