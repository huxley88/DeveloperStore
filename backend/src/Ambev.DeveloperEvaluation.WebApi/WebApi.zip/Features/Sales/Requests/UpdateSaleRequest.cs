namespace Ambev.DeveloperEvaluation.WebApi.Features.Sales.CreateSaleApiRequest
{
	public class UpdateSaleRequest
	{
		public DateTime Date { get; set; }
		public List<SaleItemRequest> Items { get; set; } = new();
	}
}
