using Ambev.DeveloperEvaluation.WebApi.Features.Customers.CreateCustomer;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Customers.UpdateCustomer;
public class UpdateCustomerApi : CreateCustomerApi { }
