using FluentValidation;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Customers.Update;

public class UpdateCustomerApiValidator : AbstractValidator<UpdateCustomerApi>
{
    public UpdateCustomerApiValidator()
    {
        RuleFor(x => x.Name).NotEmpty();
    }
}