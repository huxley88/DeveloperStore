using Ambev.DeveloperEvaluation.Application.Customers.Create;
using Ambev.DeveloperEvaluation.Application.Customers.Update;
using Ambev.DeveloperEvaluation.Application.Customers.Get;
using Ambev.DeveloperEvaluation.Application.Customers.List;
using Ambev.DeveloperEvaluation.Application.Customers.Delete;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Ambev.DeveloperEvaluation.WebApi.Features.Customers.Create;
using Ambev.DeveloperEvaluation.WebApi.Features.Customers.Update;
using Microsoft.AspNetCore.Authorization;
using Ambev.DeveloperEvaluation.WebApi.Common;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Customers;

[ApiController]
[Route("api/[controller]")]
//[Authorize]
public class CustomersController : BaseController
{
    private readonly IMediator _mediator;
    public CustomersController(IMediator mediator) => _mediator = mediator;

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 20, CancellationToken cancellationToken = default)
        => Ok(await _mediator.Send(new ListCustomersQuery(page, pageSize), cancellationToken));

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken cancellationToken)
    {
        var qv = new GetCustomerValidator();
        var qr = await qv.ValidateAsync(new GetCustomerCommand(id), cancellationToken);
        if (!qr.IsValid) return BadRequest(qr.Errors);

        var data = await _mediator.Send(new GetCustomerCommand(id), cancellationToken);
        return data is null ? NotFound() : Ok(data);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateCustomerApi req, CancellationToken cancellationToken)
    {
        var v = new CreateCustomerApiValidator();
        var r = await v.ValidateAsync(req, cancellationToken);
        if (!r.IsValid) return BadRequest(r.Errors);

        var result = await _mediator.Send(new CreateCustomerCommand() { Name = req.Name, Email = req.Email, Phone = req.Phone}, cancellationToken);
        return CreatedAtAction(nameof(Get), new { id = result.Id }, result);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateCustomerApi req, CancellationToken cancellationToken)
    {
        var v = new UpdateCustomerApiValidator();
        var r = await v.ValidateAsync(req, cancellationToken);
        if (!r.IsValid) return BadRequest(r.Errors);

        var ok = await _mediator.Send(new UpdateCustomerCommand(id,  req.Name, req.Email, req.Phone), cancellationToken);
        return ok ? NoContent() : NotFound();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(string id, CancellationToken cancellationToken)
    {
        var ok = await _mediator.Send(new DeleteCustomerCommand(id), cancellationToken);
        return ok is not null ? NoContent() : NotFound();
    }
}
