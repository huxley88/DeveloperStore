namespace Ambev.DeveloperEvaluation.WebApi.Features.Products.CreateProducts;
public class CreateProductApi
{
    public string Name { get; set; } = string.Empty;
    public decimal Price { get; set; }
}
