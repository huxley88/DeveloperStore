using Ambev.DeveloperEvaluation.Application.Products.Create;
using Ambev.DeveloperEvaluation.Application.Products.Update;
using Ambev.DeveloperEvaluation.Application.Products.Get;
using Ambev.DeveloperEvaluation.Application.Products.List;
using Ambev.DeveloperEvaluation.Application.Products.Delete;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Ambev.DeveloperEvaluation.Application.Products.GetProduct;
using Ambev.DeveloperEvaluation.WebApi.Features.Products.UpdateProducts;
using Ambev.DeveloperEvaluation.WebApi.Features.Products.CreateProducts;
using Microsoft.AspNetCore.Authorization;
using Ambev.DeveloperEvaluation.WebApi.Common;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Products;

[ApiController]
[Route("api/[controller]")]
//[Authorize]
public class ProductsController : BaseController
{
    private readonly IMediator _mediator;
    public ProductsController(IMediator mediator) => _mediator = mediator;

    [HttpGet]
    public async Task<IActionResult> List([FromQuery] int page = 1, [FromQuery] int pageSize = 20, CancellationToken cancellationToken = default)
        => Ok(await _mediator.Send(new ListProductsQuery(page, pageSize), cancellationToken));

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(Guid id, CancellationToken cancellationToken)
    {
        var qv = new GetProductValidator();
        var qr = await qv.ValidateAsync(new GetProductCommand(id), cancellationToken);
        if (!qr.IsValid) return BadRequest(qr.Errors);

        var data = await _mediator.Send(new GetProductCommand(id), cancellationToken);
        return data is null ? NotFound() : Ok(data);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateProductApi req, CancellationToken cancellationToken)
    {
        var v = new CreateProductApiValidator();
        var r = await v.ValidateAsync(req, cancellationToken);
        if (!r.IsValid) return BadRequest(r.Errors);

        var result = await _mediator.Send(new CreateProductCommand() { Name = req.Name, Price = req.Price }, cancellationToken);
        return CreatedAtAction(nameof(Get), new { id = result.Id }, result);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateProductApi req, CancellationToken cancellationToken)
    {
        var v = new UpdateProductApiValidator();
        var r = await v.ValidateAsync(req, cancellationToken);
        if (!r.IsValid) return BadRequest(r.Errors);

        var ok = await _mediator.Send(new UpdateProductCommand(id, req.Name, req.Price), cancellationToken);
        return ok ? NoContent() : NotFound();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(Guid id, CancellationToken cancellationToken)
    {
        var ok = await _mediator.Send(new DeleteProductCommand(id), cancellationToken);
        return ok is not null ? NoContent() : NotFound();
    }
}
