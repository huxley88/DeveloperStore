using Ambev.DeveloperEvaluation.WebApi.Features.Products.CreateProducts;

namespace Ambev.DeveloperEvaluation.WebApi.Features.Products.UpdateProducts;
public class UpdateProductApi : CreateProductApi { }
