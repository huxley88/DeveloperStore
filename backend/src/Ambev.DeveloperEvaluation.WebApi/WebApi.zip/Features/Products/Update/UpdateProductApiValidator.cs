using FluentValidation;
namespace Ambev.DeveloperEvaluation.WebApi.Features.Products.UpdateProducts;
public class UpdateProductApiValidator : AbstractValidator<UpdateProductApi>
{
    public UpdateProductApiValidator()
    {
        RuleFor(x => x.Name).NotEmpty();
        RuleFor(x => x.Price).GreaterThan(0);
    }
}
